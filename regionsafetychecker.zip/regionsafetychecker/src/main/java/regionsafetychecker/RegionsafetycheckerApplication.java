package regionsafetychecker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegionsafetycheckerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegionsafetycheckerApplication.class, args);
	}

}
